﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeEpicSpiesAssignment
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) 
            {
                previousCalendar.SelectedDate = DateTime.Now.Date;
                startCalendar.SelectedDate = DateTime.Now.Date.AddDays(14);
                endCalendar.SelectedDate = DateTime.Now.Date.AddDays(21);
            }
        }

        protected void okButton_Click(object sender, EventArgs e)
        {

            TimeSpan daysWorked = endCalendar.SelectedDate.Subtract(startCalendar.SelectedDate);
            int days = daysWorked.Days;
            int salary = days * 500;
            if (endCalendar.SelectedDate > startCalendar.SelectedDate.AddDays(21))
            {
                salary = salary += 1000;
            }

            if (startCalendar.SelectedDate < previousCalendar.SelectedDate.AddDays(14))
            {
                string result = string.Format("Error, Assignments must be 14 days apart, please choose a date after: {0} "
                  , previousCalendar.SelectedDate.AddDays(14)
                  .ToString());
                resultLabel.Text = result;
            }
            else
            {
                string result2 = string.Format("Assignment of {0} to assignment {1} is authorized." +
                    "<br />Budget total: {2:C}",
                    nameTextBox.Text, assignmentTextBox.Text, salary);
                    resultLabel.Text = result2;

            }
           
            



        }
    }
}