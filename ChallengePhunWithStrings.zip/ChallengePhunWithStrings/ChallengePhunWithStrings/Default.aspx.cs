﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengePhunWithStrings
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Reverse all chars in name
            string value = "Lauren Barcik";
            string result = "";
            for (int i = value.Length-1; i>=0; i--)
            {
                result += value[i];
            }
            nameLabel.Text = result.ToString();


            //Reverse the names: "Luke, Leia, Han, Chewbacca"
            
            string names =  "Luke,Leia,Han,Chewbacca";
            string[] reverseNames = names.Split(',');
            string reverseNamesResult = "";
            for (int i = reverseNames.Length - 1; i >=0; i--)
            {
                reverseNamesResult += reverseNames[i] + ",";
            }
            reverseNamesResult = reverseNamesResult.Remove(reverseNamesResult.Length - 1, 1);
            reverseLabel.Text = reverseNamesResult;


            //ascii art: luke 5/5, leia 5/5, han 5/6, chewbacca 2/3
            string art = "Luke,Leia,Han,Chewbacca";
            string artResult = "";
            string[] artNames = art.Split(',');
            for (int i = 0; i < artNames.Length; i++) 
            {
                int padLeft = (14 - artNames[i].Length) / 2;
                string temp = artNames[i].PadLeft(artNames[i].Length + padLeft, '*');
                artResult += temp.PadRight(14, '*') + "<br/>";
                
            }
            artLabel.Text = artResult;

            //puzzle: 
            //"Now is ZHEremove-me ZIME FOR ALL GOOD MEN ZO COME ZO ZHE AID OF ZHIER COUNTRY"

            string puzzleResult = "";
            string puzzle = "Now is ZHEremove-me ZIME FOR ALL GOOD MEN ZO COME ZO ZHE AID OF ZHIER COUNTRY";
            int index = puzzle.IndexOf("remove-me");
            string newPuzzle = puzzle.Remove(index, 9).Replace("Z", "T");
            puzzleResult = newPuzzle.Substring(0, 1) + newPuzzle.Substring(1).ToLower();

            puzzleLabel.Text = puzzleResult;


        }   

      
            
           
            
        
         
    }
}