﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeEpicSpiesAssetTracker
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string[] name = new string[0];
                int[] elections = new int[0];
                double[] acts = new double[0];
                ViewState.Add("Name", name);
                ViewState.Add("Elections", elections);
                ViewState.Add("Acts", acts);

            }
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            string[] name = (string[])ViewState["Name"];
            int[] elections = (int[])ViewState["Elections"];
            double[] acts = (double[])ViewState["Acts"];

            Array.Resize(ref name, name.Length + 1);
            Array.Resize(ref elections, elections.Length + 1);
            Array.Resize(ref acts, acts.Length + 1);
            
            int newestName = name.GetUpperBound(0);
            name[newestName] = nameTextBox.Text;
            int newestElection = elections.GetUpperBound(0);
            elections[newestElection] = int.Parse(electionsTextBox.Text);
            int newestActs = acts.GetUpperBound(0);
            acts[newestActs] = double.Parse(actsTextBox.Text);

            ViewState["Name"] = name;
            ViewState["Elections"] = elections;
            ViewState["Acts"] = acts;

            resultLabel.Text = String.Format("Total Elections Rigged: {0}" +
                "<br /> Average Acts of Subterfuge per Asset: {1:N2}" +
                "<br /> Last Assest You Added: {2}",
                elections.Sum(),
                acts.Average(),
                name[newestName]);

            nameTextBox.Text = "";
            electionsTextBox.Text = "";
            actsTextBox.Text = "";




        }
    }
}