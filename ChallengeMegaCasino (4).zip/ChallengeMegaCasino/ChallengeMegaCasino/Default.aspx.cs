﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengeMegaCasino
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                //Display the reels values
                string[] reels = new string[] { spinReel(), spinReel(), spinReel() };
                displayImages(reels);
                ViewState.Add("PlayersMoney", 100);
                displayPlayersMoney();

            }
       
        }

      
        protected void leverButton_Click(object sender, EventArgs e)
        {
            int betAmount = 0;
            if (!int.TryParse(betAmountTextBox.Text, out betAmount)) return;

            int winnings = pullLever(betAmount);
            displayResult(betAmount, winnings);
            adjustPlayersMoney(betAmount, winnings);
            displayPlayersMoney();
        }

        private void adjustPlayersMoney(int betAmount, int winnings)
        {
            int playersMoney = int.Parse(ViewState["PlayersMoney"].ToString());
            playersMoney -= betAmount;
            playersMoney += winnings;
            ViewState["PlayersMoney"] = playersMoney;
        }


        //set random and create spinReel attach to images
        private int pullLever(int betAmount)
        {
            string[] reels = new string[] { spinReel(), spinReel(), spinReel() };
            displayImages(reels);
            int multiplier = evaluateSpin(reels);
            return betAmount * multiplier;

        }

        private int evaluateSpin(string[] reels)
        {
            if(isBar(reels)) return 0;      
            if (isJackpot(reels)) return 100;
            int multiplier = 0;
            if (isWinner(reels, out multiplier)) return multiplier;

            return 0;
        }

        private bool isWinner(string[] reels, out int multiplier)
        {
            multiplier = determineMultiplier(reels);
            if (multiplier > 0) return true;
            return false;
        }

        private int determineMultiplier(string[] reels)
        {
            int cherryCount = determineCherryCount(reels);
            if (cherryCount == 1) return 2;
            if (cherryCount == 2) return 3;
            if (cherryCount == 3) return 4;
            return 0;
        }

        private int determineCherryCount(string[] reels)
        {
            int cherryCount = 0;
            if (reels[0] == "Cherry") cherryCount++;
            if (reels[1] == "Cherry") cherryCount++;
            if (reels[2] == "Cherry") cherryCount++;
            return cherryCount;
        }


        private bool isBar(string[] reels)
        {
            if (reels[0] == "Bar" || reels[1] == "Bar" || reels[2] == "Bar")
                return true;
            else
                return false;
        }

        private bool isJackpot(string[] reels)
        {
            if (reels[0] == "Seven" && reels[1] == "Seven" && reels[2] == "Seven")
                return true;
            else
                return false;
        }

        //create spin
        Random random = new Random();
        private string spinReel()
        {
        string[] images = new string[12] {"Strawberry","Bar","Lemon","Bell","Clover","Cherry","Diamond",
        "Orange","Seven","HorseShoe","Plum","Watermellon"};
        return images[random.Next(12)];
        }

        private void displayPlayersMoney()
        {
            moneyLabel.Text = String.Format("Player's Money: {0:C}", ViewState["PlayersMoney"]);
        }

        //set images to display
        private void displayImages(string[] reels)
        {
            Image1.ImageUrl = "/Images/" + reels[0] + ".png";
            Image2.ImageUrl = "/Images/" + reels[1] + ".png";
            Image3.ImageUrl = "/Images/" + reels[2] + ".png";
        }

        private void displayResult(int betAmount, int winnings)
        {
            if (winnings > 0)
                resultLabel.Text = String.Format("You bet {0} and you won {1:C}", betAmount, winnings);
            else
                resultLabel.Text = String.Format("Sorry you lost {0:C}. Better luck next time!", betAmount);
        }

    }
}
    

