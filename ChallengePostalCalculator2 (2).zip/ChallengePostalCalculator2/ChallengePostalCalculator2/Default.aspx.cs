﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChallengePostalCalculator2
{
    public partial class Default : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {

        }
         private void calculateTotal()
        {
            double volume = 0;
            if (!CalculateVolume(out volume)) return;
            double shipping = shippingTotal();
            double shippingCost = shipping * volume;
            resultLabel.Text = String.Format("Total cost to ship your package: {0:C}", shippingCost);
        }


        private bool CalculateVolume(out double volume)
        {
            //calculate volume and create method
            volume = 0;
            double width = 0;
            double height = 0;
            double length = 0;

            volume = (width * height * length);


            if (!Double.TryParse(widthTextBox.Text.Trim(), out width)) return false;
            if (!Double.TryParse(heightTextBox.Text.Trim(), out height)) return false;

            if (!Double.TryParse(lengthTextBox.Text.Trim(), out length)) length = 1;

            volume = width * height * length;
            return true;
        }

        public double shippingTotal()
        {
            if (groundRadioButton.Checked) return .15;
            else if (airRadioButton.Checked) return .25;
            else if (nextDayRadioButton.Checked) return .45;
            else return 0;
        }


        protected void widthTextBox_TextChanged(object sender, EventArgs e)
        {
            calculateTotal();
        }

        protected void heightTextBox_TextChanged(object sender, EventArgs e)
        {
            calculateTotal();
        }

        protected void lengthTextBox_TextChanged(object sender, EventArgs e)
        {
            calculateTotal();
        }

        protected void groundRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            calculateTotal();
        }

        protected void airRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            calculateTotal();
        }

        protected void nextDayRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            calculateTotal();
        }
    }
}
    


    


        

    

   